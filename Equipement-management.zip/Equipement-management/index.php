<?php
include("assets\config.php");
?>
<?php
include("header.php");
?>
<?php
include("sidebar.php");
?>
<?php
include("footer.php");
?>

<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
    <title>List Of Types</title>
    <style>
        h1 {
            padding: 20px;
        }

        table {
            border: 5px solid;
            padding: 50px;
        }
    </style>
</head>

<body>
    <div class="content" style="padding-bottom: 70px; ">
        <h1>List Of Types</h1>
        <hr>
        <form class="form-control bg-light" style="padding: 50px; border-radius: 30px;" method="post">
            <div class="row">
                <div class="col">
                    <input type="text" class="form-control" placeholder="Add type you want to add" name="type_name" required>
                </div>
                <div class="col">
                    <input type="submit" class="btn btn-outline-primary" name="addtype" value="Add Type">
                </div>
            </div>
        </form>
        <br>
        <table class="table">
            <thead class="thead-light">
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Type Name</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM `types`";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td>
                                <span class="editable" data-id="<?php echo $row['id']; ?>"><?php echo $row['type_name']; ?></span>
                                <input type="text" class="edit-input" data-id="<?php echo $row['id']; ?>" style="display: none;">
                            </td>
                            <td>
                                <button class="btn btn-info edit-btn" data-id="<?php echo $row['id']; ?>">Edit</button>
                                <button class="btn btn-success save-btn" data-id="<?php echo $row['id']; ?>" style="display: none;">Save</button>
                                <a class="btn btn-danger" href="delete_type.php?id=<?php echo $row['id']; ?>" id="dlt">Delete</a>
                            </td>
                        </tr>
                <?php
                    }
                }
                ?>
            </tbody>
        </table>
    </div>


    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/css/toastr.css" rel="stylesheet" />

    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/js/toastr.js"></script>
    <script>
        $(document).ready(function() {
            $('.edit-btn').click(function() {
                var id = $(this).data('id');
                var editableField = $('.editable[data-id="' + id + '"]');
                var editInput = $('.edit-input[data-id="' + id + '"]');
                var saveButton = $('.save-btn[data-id="' + id + '"]');
                editableField.hide();
                editInput.show();
                $(this).hide();
                saveButton.show();
            });

            $('.save-btn').click(function() {
                var id = $(this).data('id');
                var newValue = $('.edit-input[data-id="' + id + '"]').val();
                var saveButton = $(this);



                $.post('edit_type.php', {
                    id: id,
                    newValue: newValue
                }, function(data) {
                    if (data = 'success') {
                        // console.log(data);
                        var edited = $('.editable[data-id="' + id + '"]');
                        edited.val(newValue);
                        edited.show();
                        $('.edit-input[data-id="' + id + '"]').hide();
                        saveButton.hide();

                        alert('Type is updated');

                        window.location = 'index.php'

                    } else {

                        alert('Type is not updated');


                    }


                });

            });

        });
    </script>

</body>

</html>