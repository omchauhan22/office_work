<?php

include("assets\config.php");

if (isset($_GET['id'])) {

    $type_id = $_GET['id'];

    $sql = "DELETE FROM `types` WHERE `id`='$type_id'";

    $result = $conn->query($sql);

    if ($result == TRUE) {

        echo "<script>alert('type deleted')</script>";
        echo "<script>window.location='index.php'</script>";
    } else {

        echo "Error:" . $sql . "<br>" . $conn->error;
    }
}
