<?php

include("assets\config.php");

if (isset($_GET['id'])) {

    $item_id = $_GET['id'];

    $sql = "DELETE FROM `equipements` WHERE `id`='$item_id'";

    $result = $conn->query($sql);

    if ($result == TRUE) {

        echo "<script>alert('item deleted')</script>";
        echo "<script>window.location='equipement_list.php'</script>";
        
    } else {

        echo "Error:" . $sql . "<br>" . $conn->error;
    }
}
