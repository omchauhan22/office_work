<?php
include("assets\config.php");
?>
<?php
include_once("header.php");
?>
<?php
include_once("sidebar.php");
?>
<?php
include_once("footer.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
    <style>
        h1 {
            padding: 20px;
        }

        label {
            padding-bottom: 5px;
        }
    </style>
</head>

<body>
    <div class="content">
        <h1>Update Item</h1>
        <hr><br>
        <form class="form-control bg-light" style="padding: 50px; border: 4px solid gray; border-radius: 20px; " method="post">
            <div class="row">
                <div class="col">
                    <input type="hidden" name="id" value="<?php echo $id; ?>">
                    <label for=""><b>Update type </b> </label>
                    <select class="form-select" name="type" style="width: 80%;">
                        <?php
                        $typeQuery = mysqli_query($conn, "SELECT type_name FROM types");
                        while ($typeRow = mysqli_fetch_assoc($typeQuery)) {
                            $selected = ($typeRow['type_name'] == $type) ? 'selected' : '';
                            echo "<option value='" . $typeRow['type_name'] . "' $selected>" . $typeRow['type_name'] . "</option>";
                        }
                        ?>
                    </select>

                </div>
                <div class="col">
                    <label for=""><b>Update Brand </b> </label>
                    <input type="text" class="form-control" placeholder="" name="bname" value="<?php echo $bname; ?>" required>
                </div>
            </div>
            <br><br>
            <div class="row">
                <div class="col">
                    <label for=""><b>Update Serial number </b> </label>
                    <input type="text" class="form-control" placeholder="" name="srno" value="<?php echo $srno; ?>" required>
                </div>
                <div class="col">
                    <label for=""><b>Update Purchase date </b> </label>
                    <input placeholder="dd-mm-yyyy" type="text" onfocus="(this.type='date')" onblur="(this.type='text')" id="date" name="pdate" class="form-control" value="<?php echo $pdate; ?>" required>
                </div>
            </div>
            <br><br>
            <div class="row">
                <div class="col">
                    <label for=""><b>Update price </b> </label>
                    <input type="text" class="form-control" placeholder="" name="price" value="<?php echo $price; ?>" required>
                </div>
                <div class="col">
                    <label for=""><b>Update Devloper name </b> </label>
                    <input type="text" class="form-control" placeholder="" name="dname" value="<?php echo $dname; ?>" required>
                </div>
            </div>
            <br><br>
            <div class="row">
                <div class="col">
                    <label for=""><b>Update Status </b> </label>
                    <select class="form-select" name="status" style="width: 80%;">
                        <?php
                        $typeQuery = mysqli_query($conn, "SELECT DISTINCT wstatus FROM equipements");
                        while ($typeRow = mysqli_fetch_assoc($typeQuery)) {
                            $selected = ($typeRow['wstatus'] == $status) ? 'selected' : ''; // Check if the option should be selected
                            echo "<option value='" . $typeRow['wstatus'] . "' $selected>" . $typeRow['wstatus'] . "</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="col">

                </div>
            </div>
            <br><br>
            <center> <input type="submit" class="btn btn-primary" name="edititem" value="Update">
                <a type="submit" class="btn btn-primary" name="additem" href="equipement_list.php">Back</a>
            </center>

        </form>
    </div>
</body>

</html>