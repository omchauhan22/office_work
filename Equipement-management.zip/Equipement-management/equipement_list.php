<?php
include_once("config.php");
?>
<?php
include_once("header.php");
?>
<?php
include_once("sidebar.php");
?>
<?php
include_once("footer.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=\, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
    <style>
        button {
            width: 35%;
        }

        h1 {
            padding: 20px;
        }
    </style>
</head>

<body>
    <!-- view type -->

    <?php
    $sql = "SELECT * FROM `equipements` WHERE   1";

    $result = $conn->query($sql);
    ?>

    <div class="content">
        <h1>List Of Items</h1>

        <hr>
        <a href="add_item.php" type="button" class="btn btn-outline-primary">Add Equipement</a><br><br>


        <table class="table">
            <thead class="thead-light">
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Item Name</th>
                    <th scope="col">Serial no</th>
                    <th scope="col">Brand name</th>
                    <th scope="col">Purchase date</th>
                    <th scope="col">Price</th>
                    <th scope="col">Devloper name</th>
                    <th scope="col">Status</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php

                if ($result->num_rows > 0) {

                    while ($row = $result->fetch_assoc()) {

                ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo $row['item_type']; ?></td>
                            <td><?php echo $row['srno']; ?></td>
                            <td><?php echo $row['bname']; ?></td>
                            <td><?php echo $row['pdate']; ?></td>
                            <td><?php echo $row['price']; ?></td>
                            <td><?php echo $row['devname']; ?></td>
                            <td><?php echo $row['wstatus']; ?></td>
                            <td><a class="btn btn-info" href="edit_item.php?id=<?php echo $row['id']; ?>">Edit</a>&nbsp;
                                <a class="btn btn-danger" href="delete_item.php?id=<?php echo $row['id']; ?>">Delete</a>
                            </td>
                        </tr>
                <?php
                    }
                }
                ?>
            </tbody>
        </table>

    </div>
</body>


</html>