<?php
include_once("config.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id = $_POST["id"];
    $newValue = $_POST["newValue"];

    $sql = "UPDATE `types` SET `type_name` = '$newValue' WHERE `id` = $id";
    if ($conn->query($sql) === TRUE) {
        echo 'success';  // Return 'success' as a response
    } else {
        echo 'error';  // Return 'error' if there's a problem
    }
}
?>
