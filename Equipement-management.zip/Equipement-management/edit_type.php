<?php
include("assets\config.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id = $_POST["id"];
    $newValue = $_POST["newValue"];

    $sql = "UPDATE `types` SET `type_name` = '$newValue' WHERE `id` = $id";
    if ($conn->query($sql) === TRUE) {
        $data['msg'] = 'success';
    } else {
        $data['msg'] = 'error';  

    }
    echo json_encode($data); exit;
}
?>
