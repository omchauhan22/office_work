

<?php
$hostname = "localhost";
$username = "root";
$password = "";
$database = "equipement_management";

$conn = mysqli_connect($hostname, $username, $password, $database);

if (!$conn) {
    echo ("database not connected". mysqli_connect_error());
}
?>


<?php

//  insert type 

if (isset($_POST['addtype'])) {
    $type_name = $_POST['type_name'];


    $sql = "INSERT INTO `types` (`type_name`) VALUES ('$type_name')";

    $result = $conn->query($sql);
    if ($result == TRUE) {

        echo "<script>alert('Type is inserted')</script>";
    } else {

        echo "Error:" . $sql . "<br>" . $conn->error;
    }
}




//  insert items

if (isset($_POST['additem'])) {
    $type = $_POST['type'];
    $bname = $_POST['bname'];
    $srno = $_POST['srno'];
    $pdate = $_POST['pdate'];
    $price = $_POST['price'];
    $dname = $_POST['dname'];
    $status = $_POST['status'];

    $sql = "INSERT INTO `equipements` (`item_type`,`srno`,`bname`,`pdate`,`price`,`devname`,`wstatus`) VALUES ('" . $type . "','$srno','$bname','$pdate','$price','$dname','$status')";

    $result = $conn->query($sql);
    if ($result == TRUE) {

        echo "<script>alert('item inserted')</script>";
    } else {

        echo "Error:" . $sql . "<br>" . $conn->error;
    }
}





// update items

if (isset($_POST['edititem'])) {
    $id = $_POST['id'];
    $type = $_POST['type'];
    $bname = $_POST['bname'];
    $srno = $_POST['srno'];
    $pdate = $_POST['pdate'];
    $price = $_POST['price'];
    $dname = $_POST['dname'];
    $status = $_POST['status'];

    $sql = "UPDATE  `equipements` SET item_type='" . $type . "', srno='$srno', bname='$bname', pdate='$pdate', price='$price', devname='$dname', wstatus='$status' WHERE id='$id' ";

    $result = $conn->query($sql);
    if ($result == TRUE) {

        echo "<script>alert('item updated')</script>";
    } else {

        echo "Error:" . $sql . "<br>" . $conn->error;
    }
}

if (isset($_GET['id'])) {

    $id = $_GET['id'];

    $sql = "SELECT * FROM `equipements` WHERE `id`='$id'";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $type = $row['item_type'];
            $bname = $row['bname'];
            $srno = $row['srno'];
            $pdate = $row['pdate'];
            $price = $row['price'];
            $dname = $row['devname'];
            $status = $row['wstatus'];
        }
    }
}




?>



