<?php
include("assets\config.php");
?>
<?php
include_once("header.php");
?>
<?php
include_once("sidebar.php");
?>
<?php
include_once("footer.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
   
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
    <style>
        h1 {
            padding: 20px;
        }

        label {
            padding-bottom: 5px;
        }
       
    </style>
</head>

<body>
    <div class="content">
        <h1>Add Equipement</h1>
        <hr><br>
        <form class="form-control bg-light" style="padding: 50px; border: 4px solid gray; border-radius: 20px; " method="post">
            <div class="row">
                <div class="col">
                    <label for=""><b>Select type </b> </label>
                    <select class="form-select" name="type" style="width: 80%;" required>
                        <option value="">Select</option>
                        <?php
                        $type = mysqli_query($conn, "SELECT type_name FROM types");
                        $result = mysqli_num_rows($type);

                        while ($result = mysqli_fetch_assoc($type)) {
                            echo "<option value='" . $result['type_name'] . "'>" . $result['type_name'] . "</option>";
                        }
                        ?>
                    </select>
                </div>
                <div class="col">
                    <label for=""><b>Enter Brand </b> </label>
                    <input type="text" class="form-control" placeholder="" name="bname" required>
                </div>
            </div>
            <br><br>
            <div class="row">
                <div class="col">
                    <label for=""><b>Serial number </b> </label>
                    <input type="text" class="form-control" placeholder="" name="srno" required>
                </div>
                <div class="col">
                    <label for=""><b>Purchase date </b> </label>
                    <input placeholder="mm-dd-yyyy" type="date" onfocus="(this.type='date')" onblur="(this.type='text')" id="date" name="pdate" class="form-control"  required>
                </div>
            </div>
            <br><br>
            <div class="row">
                <div class="col">
                    <label for=""><b>Enter price </b> </label>
                    <input type="text" class="form-control" placeholder="" name="price" required>
                </div>
                <div class="col">
                    <label for=""><b>Devloper name </b> </label>
                    <input type="text" class="form-control" placeholder="" name="dname" required>
                </div>
            </div>
            <br><br>
            <div class="row">
                <div class="col">
                    <label for=""><b>Select Status </b> </label>
                    <select class="form-select" name="status" style="width: 45%;" required>
                        <option value="">Select</option>
                        <option value="working">Working</option>
                        <option value="not working">Not Working</option>
                    </select>
                </div>
                <div class="col">

                </div>
            </div>
            <br><br>
            <center>
                <input type="submit" class="btn btn-primary" name="additem" value="Submit">
                <a type="submit" class="btn btn-primary" name="additem" href="equipement_list.php">Back</a>
            </center>

        </form>
    </div>
</body>

</html>