<?php

function course(){

    $courses=['bca','mca','bscit','btech','cs'];
    echo "<select name=course >";
    echo "<option value=''>--select course--</option>";
    foreach ($courses as $course){
        echo "<option value=$course>$course</option>";
    }
    echo"</select>";
   
}