<?php

namespace App\Controllers;

use App\Models\UserModel;

class Home extends BaseController
{
    public function index(): string
    {
        return view('welcome_message');
    }

    public function insert()
    {
        $data = [
            'name' => $this->request->getVar('name'),
            'email' => $this->request->getVar('email'),
        ];

        $model = new UserModel();

        $model->insert($data);
        echo "<script>alert('Data inserted..')</script>";
        
    }

    public function show()
    {
        $model = new UserModel();

        $data['users'] = $model->findAll();

        return view('show', $data);
    }

    public function delete($id = null)
    {
        $model = new UserModel();
        $data['user'] = $model->where('id', $id)->delete($id);
       
        echo "<script>alert('Data deleted..')</script>";
        return redirect()->to(base_url('show'));
    }


    public function edit($id = null)
    {
        $model = new UserModel();
        $data['user'] = $model->where('id', $id)->first();
        return view('edit', $data);
    }


   public function update(){
        $model = new UserModel();
        $id = $this->request->getVar('id');
        $data = [
            'name' => $this->request->getVar('name'),
            'email'  => $this->request->getVar('email'),
        ];
        $model->update($id, $data);
        return $this->response->redirect(site_url('show'));
    }
}
