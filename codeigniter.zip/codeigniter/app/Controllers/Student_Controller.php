<?php
 
namespace app\Controllers;
 
use App\Models\Student_Model;
 
use App\Controllers\BaseController;
 
 
class Student_controller extends BaseController
{
 
    public function index(): string
    {
 
        return view('student_reg');
    }
 
    public function insert_stu_data()
    {
       
        $rules = [
            'firstname' => 'required|min_length[3]',
            'lastname'  => 'required|min_length[2]',
            'email'     => 'required|valid_email|is_unique[student_info.email]|min_length[10]',
            'mobile'    => 'required|regex_match[/^[0-9]{10}$/]|is_unique[student_info.mobile]',
            'gender' => 'required',
            'hobby' => 'required',
            'course' => 'required',
            'pr' => 'required',
        ];
 
        $message = [
            "email" => [
                "required" => "Email is required",
                "valid_email" => "email address is not in formate",
                "is_unique" => "email is already exist",
                "min_length" => "The minimum length of email is 10"
            ],
            "mobile" => [
                "required" => "Mobile number is required",
                "regex_match" => "Please enter only numeric value",
                "is_unique" => "mobile number is already exist"
            ],
 
        ];
        if ($this->validate($rules, $message)) {
            $model = new Student_Model();
            // echo '<pre>'; print_r($this->request->getVar()); exit;  
            $hobby = implode(', ', $_POST['hobby']);
            $file=$this->request->getFile('file');
            if($file->isValid() && ! $file->hasMoved()){
                $filename=$file->getClientExtension ();
                $file->move('uploads/',$filename);
            }
            // echo $hobby; exit;
 
            $data = [
                'firstname' => $this->request->getVar('firstname'),
                'lastname' => $this->request->getVar('lastname'),
                'email' => $this->request->getVar('email'),
                'mobile' => $this->request->getVar('mobile'),
                'gender' => $this->request->getVar('gender'),
                'hobby' => $hobby,
                'course' => $this->request->getVar('course'),
                'pr' => $this->request->getVar('pr'),
                'file'=>$filename,
            ];
            $model = new Student_Model();
            $model->insert($data);
            echo "<script>alert('Data inserted..');</script>";
            return redirect()->to('student_reg')->with('status','Student registartion is done');
    } else {
            $data['validation'] = $this->validator;
            echo view('student_reg', $data);
        }
    }
 
    public function show_stu_data()
    {
        $model = new Student_Model();
 
        $data['students'] = $model->findAll();
 
        return view('show_stu_data', $data);
    }
 
    public function edit_stu_data($stu_id = null)
    {
 
        $model = new Student_Model();
        $data['student'] = $model->where('stu_id', $stu_id)->first();
 
        return view('edit_stu_data', $data);
    }
 
    public function update_stu_data()
    {
        $model = new Student_Model();
 
        $stu_id = $this->request->getVar('stu_id');
        $data = [
            'firstname' => $this->request->getVar('firstname'),
            'lastname' => $this->request->getVar('lastname'),
            'email' => $this->request->getVar('email'),
            'mobile' => $this->request->getVar('mobile'),
            'gender' => $this->request->getVar('gender'),
            'hobby' => $this->request->getVar('hobby'),
            'course' => $this->request->getVar('course'),
            'pr' => $this->request->getVar('pr'),
        ];
        $model->update($stu_id, $data);
        echo "hello";
        return $this->response->redirect(site_url('show_stu_data'));
    }
 
    public function delete_stu_data($stu_id = null)
    {
        $model = new Student_Model();
        $data['student'] = $model->where('stu_id', $stu_id)->delete($stu_id);
 
        return redirect()->to(base_url('show_stu_data'));
        echo "<script>alert('Data deleted..');</script>";
    }
 
   
}
 