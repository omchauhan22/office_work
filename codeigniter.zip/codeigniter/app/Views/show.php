<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <table border="1px">
        <tr>
            <th>id</th>
            <th>name</th>
            <th>email</th>
            <th>Action</th>
        </tr>
        <?php foreach($users as $user){?>
            <tr>
                <td><?php  echo $user['id']; ?></td>
                <td><?php  echo $user['name']; ?></td>
                <td><?php  echo $user['email']; ?></td>
                <td><a href="<?php echo base_url('edit/'.$user['id']);?>">Edit</a>
                <a href="<?php echo base_url('delete/'.$user['id']);?>">Delete</a></td>
            </tr>

            <?php } ?>
            <button><a href="<?php echo base_url('add_user') ?>">Add user</a></button>
    </table>
</body>
</html>