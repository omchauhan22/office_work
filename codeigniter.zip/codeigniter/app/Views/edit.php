<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD</title>
    <style>
        hr {
            width: 30%;
        }

        input {
            display: block;
            padding: 8px;
            margin: 10px;
            border: hidden;
            background-color: lightcyan;
            border-bottom: 3px solid gray;
            border-radius: 5px;
        }

        .btn {
            background-color: lightgray;
            border: hidden;
            padding: 13 px;
        }
    </style>
</head>

<body>
    <center>
        <h1>Update Form</h1>
    </center>
    <hr>
    <center>

        <form action="update" method="post">
            <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
            <label for="name">name : </label>
            <input type="text" name="name" value="<?php echo $user['name']; ?>" required>

            <label for="email">email : </label>
            <input type="email" name="email" value="<?php echo $user['email']; ?>" required><br>

            <input type="submit" name="submit" value="update" class="btn">
        </form>

    </center>
</body>

</html>