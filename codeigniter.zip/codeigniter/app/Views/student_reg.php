<!DOCTYPE html>
<html lang="en">
 
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
    <title>Student Registration</title>
    <style>
        .content {
            width: 40%;
        }
        span{
            color: red;
        }
        h5{
            color: green;
        }
    </style>
</head>
 
<body>
    <center>
        <div class="content">
            <?php $validation = \Config\Services::validation();?>
            <?php
            if(session()->getFlashdata('status')){
                echo "<h5>".session()->getFlashdata('status')."</h5>";
            }

            ?>
            <h1>Fill This Form</h1>
            <hr><br>
            <form class="form-control" action="insert_stu_data" method="post" enctype="multipart/form-data">
                <div class="row">
                    <div class="col">
                        <label for=""><b>First Name : </b> </label>
                        <input type="text" class="form-control" placeholder="" name="firstname">
                        <span>
                        <?php echo $validation->getError('firstname');?>
                        </span>
                    </div>
                    <div class="col">
                        <label for=""><b>Last Name : </b> </label>
                        <input type="text" class="form-control" placeholder="" name="lastname">
                        <span>
                        <?php echo $validation->getError('lastname');?>
                        </span>
                    </div>
                </div>
                <br><br>
                <div class="row">
                    <div class="col">
                        <label for=""><b>Email : </b> </label>
                        <input type="text" class="form-control" placeholder="" name="email">
                        <span>
                        <?php echo $validation->getError('email');?>
                        </span>
                    </div>
                    <div class="col">
                        <label for=""><b>Mobile no : </b> </label>
                        <input type="text" class="form-control" name="mobile" >
                        <span>
                        <?php echo $validation->getError('mobile');?>
                        </span>
                    </div>
                </div>
                <br><br>
                <div class="row">
                    <div class="col">
                        <label for=""><b>Select Gender : </b> </label><br>
                        <input type="radio" name="gender" value="male">
                        <label for="html">Male</label>
                        <input type="radio" name="gender" value="female">
                        <label for="html">Female</label><br>
                        <span>
                        <?php echo $validation->getError('gender');?>
                        </span>
                    </div>
                    <div class="col">
                        <label for=""><b>Select Hobby : </b> </label><br>
                        <input type="checkbox" name="hobby[]" value="Reading">
                        <label class="form-check-label" for="flexCheckDefault">
                            Reading
                        </label><br>
                        <input type="checkbox" name="hobby[]" value="Writing">
                        <label class="form-check-label" for="flexCheckDefault">
                            Writing
                        </label><br>
                        <input type="checkbox" name="hobby[]" value="Coding">
                        <label class="form-check-label" for="flexCheckDefault">
                            Coding
                        </label><br>
                        <input type="checkbox" name="hobby[]" value="Traveling">
                        <label class="form-check-label" for="flexCheckDefault">
                            Traveling
                        </label><br>
                        <span>
                        <?php echo $validation->getError('hobby');?>
                        </span>
                    </div>
                </div>
                <br><br>
                <div class="row">
                    <div class="col">
                        <label for=""><b>Select Course </b> </label>
                        <!-- <select class="form-select" name="course" style="width: 45%;">
                            <option value="">Select</option>
                            <option value="BCA">BCA</option>
                            <option value="MCA">MCA</option>
                            <option value="Bsc.IT">Bsc.IT</option>
                            <option value="Msc.IT">Msc.IT</option>
                            <option value="BTech">BTech</option>
                            <option value="CS">CS</option>
                        </select> -->
                        <?=course() ?>
                        <span>
                        <?php echo $validation->getError('course');?>
                        </span>
                    </div>
                    <div class="col">
                        <label for=""><b>Percentage : </b> </label>
                        <input type="number" class="form-control" placeholder="" name="pr">
                        <span>
                        <?php echo $validation->getError('pr');?>
                        </span>
                    </div>
                </div>
                <br><br>
                <input type="file" name="file">
                <input type="date" name="date"><br><br>
                <center>
                    <input type="submit" class="btn btn-primary" name="submit" value="Submit">
                    <button><a href="<?php echo site_url('show_stu_data') ?>">Show Students</a></button>
                </center>
            </form>
        </div>
    </center>
</body>
 
</html>