<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <title>Student Data</title>
    <style>
        .content {
            width: 70%;
            padding: 30px;
        }
    </style>
</head>

<body>
    <div class="content">
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">stu_id</th>
                    <th scope="col">Firstname</th>
                    <th scope="col">Lastname</th>
                    <th scope="col">Email</th>
                    <th scope="col">Mobile</th>
                    <th scope="col">Gender</th>
                    <th scope="col">Hobby</th>
                    <th scope="col">Course</th>
                    <th scope="col">Percentage</th>
                    <th>Action</th>
                </tr>
            </thead>
            <?php foreach ($students as $student) { ?>
                <tr>
                    <td><?php echo $student['stu_id']; ?></td>
                    <td><?php echo $student['firstname']; ?></td>
                    <td><?php echo $student['lastname']; ?></td>
                    <td><?php echo $student['email']; ?></td>
                    <td><?php echo $student['mobile']; ?></td>
                    <td><?php echo $student['gender']; ?></td>
                    <td><?php echo $student['hobby']; ?></td>
                    <td><?php echo $student['course']; ?></td>
                    <td><?php echo $student['pr']; ?></td>
                    <td><a class="btn btn-info" href="<?php echo base_url('edit_stu_data/' . $student['stu_id']); ?>">Edit</a>
                        <a class="btn btn-danger" href="<?php echo base_url('delete_stu_data/' . $student['stu_id']); ?>">Delete</a>
                    </td>
                </tr>
            <?php } ?>
        </table>
        <button><a href="<?php echo base_url('student_reg') ?>">Add student</a></button>
    </div>
</body>

</html>