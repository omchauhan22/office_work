<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD</title>
    <style>
        hr{
            width: 30%;
        }

        input{
            display: block;
            padding: 8px;
            margin: 10px;
            border: hidden;
            background-color: lightcyan;
            border-bottom: 3px solid gray;
            border-radius: 5px;
        }
        .btn{
            background-color: lightgray;
            border: hidden;
            padding: 13 px;            
        }   
    </style>
</head>

<body>
    <center>
        <h1>WELCOME</h1>
    </center>
    <hr>
    <center>
       
        <form action="insert" method="post">
            <label for="name">name : </label>
            <input type="text" name="name" required>

            <label for="email">email : </label>
            <input type="email" name="email" required><br>

            <input type="submit" name="submit" value="submit" class="btn">
        </form>
        <button><a href="<?php echo site_url('show') ?>">Show Users</a></button>
    </center>
  
</body>

</html>