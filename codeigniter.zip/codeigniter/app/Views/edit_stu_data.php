<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
    <title>Student Registration</title>
    <style>
        .content {
            width: 40%;
        }
    </style>
</head>

<body>
    <center>
        <div class="content">
            <h1>Update Your Details</h1>
            <hr><br>
            <form class="form-control" action="<?= site_url('update_stu_data') ?>" method="post">
                <input type="hidden" name="stu_id" value="<?php echo $student['stu_id']; ?>">
                <div class="row">
                    <div class="col">
                        <label for=""><b>First Name : </b> </label>
                        <input type="text" class="form-control" placeholder="" name="firstname" value="<?php echo $student['firstname']; ?>" required>
                    </div>
                    <div class="col">
                        <label for=""><b>Last Name : </b> </label>
                        <input type="text" class="form-control" placeholder="" name="lastname" value="<?php echo $student['lastname']; ?>" required>
                    </div>
                </div>
                <br><br>
                <div class="row">
                    <div class="col">
                        <label for=""><b>Email : </b> </label>
                        <input type="text" class="form-control" placeholder="" name="email" value="<?php echo $student['email']; ?>" required>
                    </div>
                    <div class="col">
                        <label for=""><b>Mobile no : </b> </label>
                        <input type="text" class="form-control" name="mobile" pattern="[0-9]{10}" value="<?php echo $student['mobile']; ?>" maxlength="10" required>
                    </div>
                </div>
                <br><br>
                <div class="row">
                    <div class="col">
                        <label for=""><b>Select Gender : </b> </label><br>
                        <input type="radio" name="gender" value="male" <?php echo (!empty($student['gender'] == 'male')) ? 'checked="checked"' : ''; ?>>
                        <label for="html">Male</label>
                        <input type="radio" name="gender" value="female" <?php echo (!empty($student['gender'] == 'female')) ? 'checked="checked"' : ''; ?>>
                        <label for="html">Female</label><br>
                    </div>
                    <div class="col">
                       <?php 
                    //    $hobbys = explode(', ',$student['hobby']);
                    //    if(in_array("Writing",$hobbys)) {
                    //     echo 'yes'; exit;
                    //    } else {
                    //     echo 'no'; exit;
                    //    }
                    //    print_r($hobbys); exit;
                       ?>
                        <label for=""><b>Select Hobby : </b> </label><br>
                        <input type="checkbox" name="hobby[]" value="Reading" <?php echo (in_array("Reading", explode(', ',$student['hobby']))) ? 'checked="checked"' : ''; ?>>
                        <label class="form-check-label" for="flexCheckDefault">
                            Reading
                        </label><br>
                        <input type="checkbox" name="hobby[]" value="Writing" <?php echo (in_array("Writing", explode(', ',$student['hobby']))) ? 'checked="checked"' : ''; ?>>
                        <label class="form-check-label" for="flexCheckDefault">
                            Writing
                        </label><br>
                        <input type="checkbox" name="hobby[]" value="Coding" <?php echo (in_array("Coding",explode(', ',$student['hobby']))) ? 'checked="checked"' : ''; ?>>
                        <label class="form-check-label" for="flexCheckDefault">
                            Coding
                        </label><br>
                        <input type="checkbox" name="hobby[]" value="Traveling" <?php echo (in_array("Traveling", explode(', ',$student['hobby']))) ? 'checked="checked"' : ''; ?>>
                        <label class="form-check-label" for="flexCheckDefault">
                            Traveling
                        </label>
                    </div>
                </div>
                <br><br>
                <div class="row">
                    <div class="col">
                        <label for=""><b>Select Course </b> </label>
                        <select class="form-select" name="course" style="width: 45%;" required>
                            <option value="">Select</option>
                            <option value="BCA" <?php echo (!empty($student['course'] == 'BCA')) ? 'selected="selected"' : ''; ?>>BCA</option>
                            <option value="MCA" <?php echo (!empty($student['course'] == 'MCA')) ? 'selected="selected"' : ''; ?>>MCA</option>
                            <option value="Bsc.IT" <?php echo (!empty($student['course'] == 'Bsc.IT')) ? 'selected="selected"' : ''; ?>>Bsc.IT</option>
                            <option value="Msc.IT" <?php echo (!empty($student['course'] == 'Msc.IT')) ? 'selected="selected"' : ''; ?>>Msc.IT</option>
                            <option value="BTech" <?php echo (!empty($student['course'] == 'BTech')) ? 'selected="selected"' : ''; ?>>BTech</option>
                            <option value="CS" <?php echo (!empty($student['course'] == 'CS')) ? 'selected="selected"' : ''; ?>>CS</option>
                        </select>
                    </div>
                    <div class="col">
                        <label for=""><b>Percentage : </b> </label>
                        <input type="number" class="form-control" placeholder="" name="pr" value="<?php echo $student['pr']; ?>" required>
                    </div>
                </div>
                <input type="file" name="file" value="<?php echo $student['file']; ?>"><br><br>
                <br><br>
                <center>
                    <input type="submit" class="btn btn-primary" value="Update">
                </center>

            </form>
        </div>
    </center>
</body>

</html>