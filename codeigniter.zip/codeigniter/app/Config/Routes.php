<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
// CRUD RESTful Routes
// $routes->get('/', 'Home::index');
// $routes->post('insert', 'Home::insert');
// $routes->get('show', 'Home::show');
// $routes->get('delete/(:num)', 'Home::delete/$1');
// $routes->get('edit/(:num)', 'Home::edit/$1');
// $routes->post('update', 'Home::update');
// $routes->get('add_user', 'Home::index');


// STUDENT Registration Routes

$routes->get('/', 'Student_controller::index');
// $routes->match(['get', 'post'], 'Student_controller::index');
$routes->match(['get', 'post'],'insert_stu_data', 'Student_controller::insert_stu_data');
$routes->get('show_stu_data', 'Student_controller::show_stu_data');
$routes->get('edit_stu_data/(:num)', 'Student_controller::edit_stu_data/$1');
$routes->post('update_stu_data', 'Student_controller::update_stu_data');
$routes->get('delete_stu_data/(:num)', 'Student_controller::delete_stu_data/$1');
$routes->get('student_reg', 'Student_controller::index');
