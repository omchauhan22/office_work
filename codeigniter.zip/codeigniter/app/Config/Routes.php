<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
// CRUD RESTful Routes
$routes->get('/', 'Home::index');
$routes->post('insert', 'Home::insert');
$routes->get('show', 'Home::show');
$routes->delete('delete/(:num)', 'Home::delete$1');
$routes->get('edit/(:num)', 'Home::edit/$1');
$routes->post('update/', 'Home::update');






