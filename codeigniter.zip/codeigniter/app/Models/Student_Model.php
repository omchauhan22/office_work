<?php

namespace App\Models;

use CodeIgniter\Model;

class Student_Model extends Model{

    protected $table = 'student_info';
    protected $primaryKey = 'stu_id';

    protected $allowedFields = ['firstname', 'lastname', 'email', 'mobile', 'gender', 'hobby', 'course', 'pr'];

}